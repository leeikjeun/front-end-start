var api = {
    apiurl : "https://apis.daum.net/search/" ,
    board : "board?", // 게시판
    image : "image?",//이미지
    vclip : "vclip?",//동영상
    blog : "blog?",//블로그
    knowledge : "knowledge?",//팁
    cafe : "cafe?",//카페
    apikey : "apikey=d5c6201c38da05dc26bce3b8cd665e85&q=",
    keyword : "",
    pageno : "&pageno=",
    page : 1,
    output : "&output=json",
};

var completion ={
    apiurl : "",
    
    };